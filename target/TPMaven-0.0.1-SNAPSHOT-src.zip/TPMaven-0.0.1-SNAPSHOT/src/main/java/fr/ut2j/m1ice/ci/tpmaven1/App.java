package fr.ut2j.m1ice.ci.tpmaven1;

/**
 * Hello world.
 *
 */
public final class App {
    /**
    *
    * private constructor.
    */
    private App() {
    }
    /**
    *
    * main.
    *
    * @param args tableaux de string
    */
    public static void main(final String[] args) {
        System.out.println("Hello World!");
    }
}
